/-
Copyright (c) 2026 Juan Pablo Traverso Gianini.
Released under Apache 2.0 license as described in the file LICENSE.
Original mathematical attributions and third-party notices are retained below.
-/

/-
Paper V formalization and integration.
Authors: Juan Pablo Traverso Gianini

Original mathematical attributions and existing source/port provenance are
retained below; this author credit does not reattribute those prior results.
-/

/-
Paper IV — Brooks B, structural half of the cut-vertex reduction.

Given a 3-regular `G` and a cut vertex `x` presented as a partition `V∖{x} = A₀ ⊔ B₀` with both
sides nonempty, no edge crossing `A₀—B₀`, and both `G[{x}∪A₀]`, `G[{x}∪B₀]` connected, this file
proves `G.Colorable 3` outright (`colorable_of_cut_partition`): each side carries `x` at degree
`< 3` (it has a neighbour on the far side), so the non-regular case `connected_colorable_three_of_
exists_degree_lt` colours it, and `colorable_glue_at_vertex` merges the two at `x`.

Together with `BrooksGlue`, `BrooksCutExists`, and the Lovász cut-existence step, this discharges
the `no good triple` case in `BrooksReg`.
-/
module

public import PaperV.BrooksGlue
public import PaperV.BrooksNonRegular

import Lean.Elab.Tactic.Omega
import Mathlib.Tactic.Push
import Mathlib.Tactic.Set

@[expose] public section

open SimpleGraph Finset

namespace PaperV.Brooks

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- Induced degree never exceeds the ambient degree. -/
theorem induce_degree_le (G : SimpleGraph V) [DecidableRel G.Adj] (S : Set V)
    [DecidablePred (· ∈ S)] [DecidableRel (G.induce S).Adj] (w : ↥S) :
    (G.induce S).degree w ≤ G.degree w.val := by
  have hsub : ((G.induce S).neighborFinset w).image Subtype.val ⊆ G.neighborFinset w.val := by
    intro z hz
    rw [Finset.mem_image] at hz
    obtain ⟨y, hy, rfl⟩ := hz
    rw [mem_neighborFinset] at hy ⊢
    simpa [SimpleGraph.induce, SimpleGraph.comap] using hy
  calc (G.induce S).degree w
      = ((G.induce S).neighborFinset w).card := ((G.induce S).card_neighborFinset_eq_degree w).symm
    _ = (((G.induce S).neighborFinset w).image Subtype.val).card :=
        (Finset.card_image_of_injective _ Subtype.val_injective).symm
    _ ≤ (G.neighborFinset w.val).card := Finset.card_le_card hsub
    _ = G.degree w.val := G.card_neighborFinset_eq_degree _

/-- **B, cut-vertex reduction (structural half).** Given a 3-regular `G`, a vertex `x`, and a
partition of `V∖{x}` into nonempty `A₀,B₀` with no edge crossing between them, such that both
`G[{x}∪A₀]` and `G[{x}∪B₀]` are connected, `G` is 3-colourable: each side has `x` at degree `< 3`
(it has a neighbour on the other side), so the non-regular case colours it, and the glue lemma
merges them at `x`. This discharges everything downstream of the Lovász cut-existence step. -/
theorem colorable_of_cut_partition (G : SimpleGraph V) [DecidableRel G.Adj]
    (hreg : ∀ v, G.degree v = 3)
    (x : V) (A₀ B₀ : Finset V)
    (hAne : A₀.Nonempty) (hBne : B₀.Nonempty)
    (hxnA : x ∉ A₀) (hxnB : x ∉ B₀)
    (hdisj : Disjoint A₀ B₀)
    (hcov : insert x (A₀ ∪ B₀) = Finset.univ)
    (hnocross : ∀ a ∈ A₀, ∀ b ∈ B₀, ¬ G.Adj a b)
    (hAconn : (G.induce ((insert x A₀ : Finset V) : Set V)).Connected)
    (hBconn : (G.induce ((insert x B₀ : Finset V) : Set V)).Connected) :
    G.Colorable 3 := by
  classical
  set A : Finset V := insert x A₀ with hA
  set B : Finset V := insert x B₀ with hB
  have hxA : x ∈ A := Finset.mem_insert_self _ _
  have hxB : x ∈ B := Finset.mem_insert_self _ _
  have hcover : A ∪ B = Finset.univ := by
    rw [hA, hB, Finset.insert_union, Finset.union_insert, ← hcov]
    -- insert x (insert x (A₀ ∪ B₀)) collapses
    rw [Finset.insert_idem]
  -- decidable instances for the induced graphs
  haveI : DecidableRel (G.induce ((A : Finset V) : Set V)).Adj := Classical.decRel _
  haveI : DecidableRel (G.induce ((B : Finset V) : Set V)).Adj := Classical.decRel _
  -- helper: `x` has a neighbour on a connected side other than `x` itself
  have hxneighbor : ∀ (C₀ : Finset V), C₀.Nonempty → x ∉ C₀ →
      (G.induce ((insert x C₀ : Finset V) : Set V)).Connected →
      ∃ z ∈ C₀, G.Adj x z := by
    intro C₀ hCne hxnC hCconn
    obtain ⟨c₀, hc₀⟩ := hCne
    have hxmem : x ∈ ((insert x C₀ : Finset V) : Set V) := by
      simp
    have hcmem : c₀ ∈ ((insert x C₀ : Finset V) : Set V) := by
      simp [hc₀]
    have hne : (⟨x, hxmem⟩ : ↥((insert x C₀ : Finset V) : Set V)) ≠ ⟨c₀, hcmem⟩ := by
      intro h
      apply hxnC
      have : x = c₀ := congrArg Subtype.val h
      rw [this]; exact hc₀
    obtain ⟨p⟩ := hCconn.preconnected ⟨x, hxmem⟩ ⟨c₀, hcmem⟩
    cases p with
    | nil => exact absurd rfl hne
    | cons hadj q =>
        rename_i z
        refine ⟨z.val, ?_, ?_⟩
        · have hzmem := z.property
          simp only [Finset.coe_insert, Set.mem_insert_iff, Finset.mem_coe] at hzmem
          have hzx : z.val ≠ x := by
            intro h
            have : G.Adj x x := by
              have : G.Adj x z.val := by simpa [SimpleGraph.induce, SimpleGraph.comap] using hadj
              rwa [h] at this
            exact this.ne rfl
          rcases hzmem with h | h
          · exact absurd h hzx
          · exact h
        · simpa [SimpleGraph.induce, SimpleGraph.comap] using hadj
  -- x has a neighbour in B₀ and in A₀
  obtain ⟨bz, hbz0, hxbz⟩ := hxneighbor B₀ hBne hxnB hBconn
  obtain ⟨az, haz0, hxaz⟩ := hxneighbor A₀ hAne hxnA hAconn
  -- colour each side by the non-regular case
  have hApiece : (G.induce ((A : Finset V) : Set V)).Colorable 3 := by
    apply connected_colorable_three_of_exists_degree_lt _ hAconn
    · intro v
      have h1 : ((G.induce ((A : Finset V) : Set V)).neighborFinset v).image Subtype.val
          ⊆ G.neighborFinset v.val := by
        intro z hz; rw [Finset.mem_image] at hz; obtain ⟨y, hy, rfl⟩ := hz
        rw [mem_neighborFinset] at hy ⊢
        simpa [SimpleGraph.induce, SimpleGraph.comap] using hy
      calc (G.induce ((A : Finset V) : Set V)).degree v
          = ((G.induce ((A : Finset V) : Set V)).neighborFinset v).card :=
            ((G.induce _).card_neighborFinset_eq_degree v).symm
        _ = (((G.induce ((A : Finset V) : Set V)).neighborFinset v).image Subtype.val).card :=
            (Finset.card_image_of_injective _ Subtype.val_injective).symm
        _ ≤ (G.neighborFinset v.val).card := Finset.card_le_card h1
        _ = 3 := by rw [G.card_neighborFinset_eq_degree, hreg v.val]
    · -- x has degree < 3 in G[A] : misses its B₀-neighbour bz
      have hxmem : x ∈ ((A : Finset V) : Set V) := by simp [hA]
      refine ⟨⟨x, hxmem⟩, ?_⟩
      have hbznotA : bz ∉ A := by
        rw [hA, Finset.mem_insert]; push_neg
        exact ⟨fun h => hxnB (h ▸ hbz0), fun h => (Finset.disjoint_left.mp hdisj h) hbz0⟩
      have hsub : ((G.induce ((A : Finset V) : Set V)).neighborFinset ⟨x, hxmem⟩).image Subtype.val
          ⊆ (G.neighborFinset x).erase bz := by
        intro z hz
        rw [Finset.mem_image] at hz
        obtain ⟨y, hy, rfl⟩ := hz
        rw [mem_neighborFinset] at hy
        rw [Finset.mem_erase, mem_neighborFinset]
        have hadjxy : G.Adj x y.val := by simpa [SimpleGraph.induce, SimpleGraph.comap] using hy
        refine ⟨?_, hadjxy⟩
        intro h
        apply hbznotA
        rw [← h]; exact y.property
      have hbzmem : bz ∈ G.neighborFinset x := by rw [mem_neighborFinset]; exact hxbz
      calc (G.induce ((A : Finset V) : Set V)).degree ⟨x, hxmem⟩
          = ((G.induce ((A : Finset V) : Set V)).neighborFinset ⟨x, hxmem⟩).card :=
            ((G.induce _).card_neighborFinset_eq_degree _).symm
        _ = (((G.induce ((A : Finset V) : Set V)).neighborFinset ⟨x, hxmem⟩).image Subtype.val).card :=
            (Finset.card_image_of_injective _ Subtype.val_injective).symm
        _ ≤ ((G.neighborFinset x).erase bz).card := Finset.card_le_card hsub
        _ = G.degree x - 1 := by rw [Finset.card_erase_of_mem hbzmem, G.card_neighborFinset_eq_degree]
        _ < 3 := by have := hreg x; omega
  have hBpiece : (G.induce ((B : Finset V) : Set V)).Colorable 3 := by
    apply connected_colorable_three_of_exists_degree_lt _ hBconn
    · intro v
      have h1 : ((G.induce ((B : Finset V) : Set V)).neighborFinset v).image Subtype.val
          ⊆ G.neighborFinset v.val := by
        intro z hz; rw [Finset.mem_image] at hz; obtain ⟨y, hy, rfl⟩ := hz
        rw [mem_neighborFinset] at hy ⊢
        simpa [SimpleGraph.induce, SimpleGraph.comap] using hy
      calc (G.induce ((B : Finset V) : Set V)).degree v
          = ((G.induce ((B : Finset V) : Set V)).neighborFinset v).card :=
            ((G.induce _).card_neighborFinset_eq_degree v).symm
        _ = (((G.induce ((B : Finset V) : Set V)).neighborFinset v).image Subtype.val).card :=
            (Finset.card_image_of_injective _ Subtype.val_injective).symm
        _ ≤ (G.neighborFinset v.val).card := Finset.card_le_card h1
        _ = 3 := by rw [G.card_neighborFinset_eq_degree, hreg v.val]
    · have hxmem : x ∈ ((B : Finset V) : Set V) := by simp [hB]
      refine ⟨⟨x, hxmem⟩, ?_⟩
      have haznotB : az ∉ B := by
        rw [hB, Finset.mem_insert]; push_neg
        exact ⟨fun h => hxnA (h ▸ haz0), fun h => (Finset.disjoint_right.mp hdisj h) haz0⟩
      have hsub : ((G.induce ((B : Finset V) : Set V)).neighborFinset ⟨x, hxmem⟩).image Subtype.val
          ⊆ (G.neighborFinset x).erase az := by
        intro z hz
        rw [Finset.mem_image] at hz
        obtain ⟨y, hy, rfl⟩ := hz
        rw [mem_neighborFinset] at hy
        rw [Finset.mem_erase, mem_neighborFinset]
        have hadjxy : G.Adj x y.val := by simpa [SimpleGraph.induce, SimpleGraph.comap] using hy
        refine ⟨?_, hadjxy⟩
        intro h
        apply haznotB
        rw [← h]; exact y.property
      have hazmem : az ∈ G.neighborFinset x := by rw [mem_neighborFinset]; exact hxaz
      calc (G.induce ((B : Finset V) : Set V)).degree ⟨x, hxmem⟩
          = ((G.induce ((B : Finset V) : Set V)).neighborFinset ⟨x, hxmem⟩).card :=
            ((G.induce _).card_neighborFinset_eq_degree _).symm
        _ = (((G.induce ((B : Finset V) : Set V)).neighborFinset ⟨x, hxmem⟩).image Subtype.val).card :=
            (Finset.card_image_of_injective _ Subtype.val_injective).symm
        _ ≤ ((G.neighborFinset x).erase az).card := Finset.card_le_card hsub
        _ = G.degree x - 1 := by rw [Finset.card_erase_of_mem hazmem, G.card_neighborFinset_eq_degree]
        _ < 3 := by have := hreg x; omega
  -- glue
  have hcross : ∀ u ∈ A, ∀ w ∈ B, u ≠ x → w ≠ x → ¬ G.Adj u w := by
    intro u hu w hw hux hwx
    have huA0 : u ∈ A₀ := by
      rw [hA, Finset.mem_insert] at hu; exact hu.resolve_left hux
    have hwB0 : w ∈ B₀ := by
      rw [hB, Finset.mem_insert] at hw; exact hw.resolve_left hwx
    exact hnocross u huA0 w hwB0
  exact colorable_glue_at_vertex G A B x hcover hxA hxB hcross hApiece hBpiece

end PaperV.Brooks
