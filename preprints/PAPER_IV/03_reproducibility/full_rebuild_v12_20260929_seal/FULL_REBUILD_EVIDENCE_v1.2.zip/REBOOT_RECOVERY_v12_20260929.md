# Paper IV v1.2: full-rebuild recovery after PC restart

The PC boot record is 2026-09-29 17:34:57 local time. The original fresh
reconstruction stopped with 422 completed PASS rows, while module 423,
`E34.SampleBound`, was running. No final build summary or success exit exists
for that interrupted run. Its stale RUNNING marker is not evidence of a live
process. No Lean/Lake process was active at the recovery inspection.

The recovery preflight verified all 615 frozen source entries in both the source
tree and working copy. For each of the 422 completed modules it also verified
the source hash, compiled object hash, exact build options, direct local-import
object hashes, pinned dependency identities, Lean version, successful log and
exit record, and complete build trace. No unmatched reusable trace was present.
The five interfaces requested by the reviewer remain part of the 607-module
scope; all 19 selected audit/export targets are to be freshly executed again.

The interrupted module has no certified finished object and is compiled again.
The recovery does not use project objects from before this full reconstruction.
It does reuse objects certified in its first segment. Shared Mathlib and package
caches remain unchanged. No source or mathematical proof has been modified.

## Evidence

- First segment (preserved): `full_rebuild_v12_20260929_r2/`.
- Recovery: `full_rebuild_v12_20260929_resume/RECOVERY_CHECK.json`.
- Second segment: `full_rebuild_v12_20260929_resume/combined/`.
- If completed successfully, the recovery wrapper writes
  `COMBINED_FRESH_PROVENANCE.json` and `FULL_REBUILD_VALIDATION.json`.
- Wrapper: `resume_full_rebuild_v12_20260929.py`.

The recovery preflight is PASS, not the build or manuscript audit. The final
acceptance criterion is a fresh successful compilation record for every one of
the 607 modules across the two segments, intact sources, zero unexplained
cache reuse, all 19 audit targets and 224 export checks passing. The second
segment may report UP-TO-DATE only for objects tied to the first segment's
validated PASS records. This replaces the single-run zero-cache-hit criterion:
do not describe the resumed run alone as 607 fresh compilations.

Freeze and manuscript evidence must disclose the two-segment reconstruction.
No freeze is approved until the combined validation succeeds. Internal audit,
manuscript resealing and publication have not been performed by this recovery.
