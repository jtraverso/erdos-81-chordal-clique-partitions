# Paper IV v1.2 — bilingual manuscript freeze for renewed audit

**State: EDITORIAL_DRAFT_WITH_OPEN_GATES. Locally identified candidate, not a publication or an audit PASS.**

The approved English text and its synchronized Spanish edition are available as
Markdown, LaTeX and PDF. The Markdown files are the semantic sources; the two
series templates and builders determine layout. Version **1.2** is retained.

## Read and review

- PAPER_IV_preprint_v1.2_en.{md,tex,pdf}: English, 68 PDF pages.
- PAPER_IV_preprint_v1.2_es.{md,tex,pdf}: Spanish, 69 PDF pages.
- BILINGUAL_FREEZE_REPORT.md: changes, validation scope, visual review and limitations.
- ARTIFACT_CHECKS.json and BILINGUAL_CHECKS.json: checks of the final files.
- MANUSCRIPT_MANIFEST.json and MANUSCRIPT_FREEZE.json: sealed file identity,
  archive identity and the link to the unchanged Lean cut.
- NEXT_INTERNAL_AUDIT_SCOPE_v1.2.md: the next audit's inputs and expanded scope.
- BILINGUAL_APPROVED_EN.diff: the four editorial differences from approved English.

MANUSCRIPT_FREEZE.json is a detached record beside the manuscript files and in
04_integrity; it is not inside its own ZIP, whose hash it records. The ZIP contains
the complete file manifest. Integrity checks that inspect Lean evidence require
the accompanying repository layout and source/evidence packages.

## Frozen Lean authority

The selected source cut remains **piv-v12-fb459343d234**:

- Source tree: ../../05_formalization/lean_piv-v12-fb459343d234/.
- Freeze record: ../../04_integrity/FREEZE_piv-v12-fb459343d234.json.
- Evidence: ../../03_reproducibility/build_piv-v12-fb459343d234/.
- 607 Lean modules; 615 manifested source/configuration/documentation entries.
- 19 freshly executed targets, 224 exports, 461 standard-axiom records.
  Records are not a count of distinct theorems.
- The recorded serial run compiled 19 modules and validated 588 cache hits.
- The cut includes E35, explicit public Theorem C and the square-root obstruction.
- No Lean file was changed and no new Lean build was run in this editorial pass.

The complete target list is in the source freeze record. The single command
`python tools/audit_publication.py` runs the selected targets; it is not a claim
that all targets share one monolithic import environment. Reuse the existing
pinned Mathlib cache. Do not install another Mathlib.

## Reproduction of the manuscripts

Use `build_draft_en.py` and `build_draft.py` with the existing Pandoc/Tectonic
runtime indicated in their configuration. They use the final Markdown and
the included vector figures, compile the delivered TeX twice, and render the
PDFs. Do not regenerate figures or translations merely to compile the paper.

`check_release_artifacts.py` checks preservation, bilingual structure, the
recorded source identity and final compiler/render binding. It does not prove
the mathematics and does not run Lean. Recompilation creates a new PDF identity;
rerender, review, check and reseal before using it as an audit input.

The translation-preparation scripts and review records are historical working
aids, not authorities for overwriting the finalized Spanish Markdown.

## History and next gate

Earlier review inputs and reports remain in review_history and in the previous
candidate folders. Reports headed V1.2_EN, R2, O1_O5 and R3 describe earlier
checkpoints; their hashes and statements of pending work apply to those cuts.
The current report is BILINGUAL_FREEZE_REPORT.md.

Next: run a **new internal audit** on the exact manuscript pair and the selected
Lean cut, following the existing internal standard and the expanded scope note.
Then request a new external adversarial cycle. Earlier internal/external verdicts
do not certify v1.2. No GitHub push, tag, publication, DOI assignment or external
submission was performed.
