# Paper IV v1.2 — inputs for the next internal audit

**PLANNED_NOT_EXECUTED.** This note identifies the enlarged scope; it does not
activate an audit and does not replace the internal standard.

## Exact inputs

1. The six manuscripts and their assets listed in MANUSCRIPT_MANIFEST.json.
2. The manuscript ZIP identified by MANUSCRIPT_FREEZE.json.
3. Lean cut `piv-v12-fb459343d234`, its source manifest/archive and recorded
   combined build, identified in the same freeze record.
4. V1.2_CLAIM_MAP.md, the manuscript's statement/implementation tables, and
   the existing `../../02_validation/INTERNAL_AUDIT_STANDARD_v1.0.md`.

Begin by checking hashes and using a new execution directory. Never overwrite
the earlier audits. The earlier protocol's version-specific module counts,
targets and claim inventory must be replaced by this cut's literal inputs,
not carried forward as assertions. Review the full protocol before execution.

## Content requiring renewed coverage

- Theorem A, B, C and C′, with their different ranges and quantifiers.
- Chordal and fixed-defect same-root bounds, unrestricted partition counts,
  edge mass, and the distinction between an actual clique root and resizing
  to an optimal-size template.
- Proposition 6.3a: the formal square-root obstruction, its family, constants
  and universal quantification over optimally sized comparison templates.
- The uniform finite fractional bounds and the arbitrary-order sublinear
  sequence result; no substitution of a growing parameter into a fixed-parameter
  theorem is permitted.
- Explicit public E34/E35 chains, tower propagation, the selected-removal audit,
  and the exact scope of the exclusion of Alon–Shapira from selected public cones.
- Expanded retained accounts in E.4, clique recovery in F.3, and the three-case
  pinned-sample argument in F.5. Prose-to-Lean verification remains required.
- Attribution to [5], [15] and [22], including what coincides, what is adapted
  and what the restricted order of pieces strengthens. No priority assertion.
- Bilingual semantic and visual parity after the last typesetting pass.

## Execution limits

Reuse pinned dependencies and the existing Mathlib installation; no additional
Mathlib download. Do not start a complete Lean rebuild by default. First inspect
the recorded build and decide whether a narrowly scoped reconstruction is needed.
Maximum one heavy process. Certo checks must have explicit specifications and
independently verifiable certificates, and finite tests are not universal proofs.

Produce the standard per-block scripts, inputs, outputs, MD/PDF reports and ZIPs,
followed by a general report and sealed archive. New audit outcomes must not be
inferred from ARTIFACT_CHECKS.json: that file only checks editorial artifacts
and the integrity of existing evidence. No publication or external submission
is authorized by this note.
