# Paper IV v1.21 — siguiente revisión

Revisión propuesta: **v1.21-r1**, sólo editorial/expositiva sobre el mismo Lean congelado. No es una auditoría iniciada ni una versión publicada.

## Insumos

- Los seis manuscritos ES/EN en MD, TeX y PDF y las figuras de esta carpeta, identificados en `MANUSCRIPT_REVIEW_MANIFEST.json`.
- `RESPONSE_TO_AUDIT_v1.21.md`, diferencias de texto `CHANGES_*.diff`, comprobaciones semánticas, de artefactos y revisión visual.
- `EVIDENCE_AND_ANNEX_CORRIGENDUM.md` y recuento reproducido de axiomas.
- El mismo corte Lean `piv-v12-fb459343d234`, manifiesto `fb459343d234f968d7d32eff1491ea8a09aa2e135b313a80623012e7449042f5`, y el mismo anexo `BoundedCliqueGap`. No se añaden fuentes matemáticas.
- La ejecución externa `run_v1.2_r1`, **cuando haya terminado**: informe final, SUMMARY, logs completos, códigos de salida, tipos, huellas, exportaciones y anexo. No sustituir estos documentos por un contador de módulos.

## Preparación y condición de inicio

El mandato está en:

`C:/Users/jtraverso/e81p4-publish/preprints/PAPER_IV/02_validation/02_IA_ADVERSARIAL_AUDITS/EXTERNAL_ADVERSARIAL_AUDIT_REQUEST_v1.21.md`

Destino reservado para los resultados, sin iniciar la revisión:

`C:/Users/jtraverso/e81p4-publish/preprints/PAPER_IV/02_validation/02_IA_ADVERSARIAL_AUDITS/run_v1.21_r1/`

Antes de pedir su ejecución: contrastar todos los hallazgos finales de v1.2-r1 con la respuesta de esta carpeta y vincular por hashes su evidencia formal final. Si aparece un fallo Lean, un defecto matemático nuevo o una diferencia en fuentes, detener el pase editorial y diagnosticarlo; no declarar el candidato listo por anticipado. Si sólo quedan las incidencias ya tratadas, se puede revisar v1.21 sin reformalizar el teorema.

La evidencia de un build externo válido puede seguir sirviendo para **las mismas fuentes, opciones y dependencias**, aunque cambien los manuscritos. El auditor deberá comprobar esa identidad, aceptar y declarar explícitamente la reutilización y repetir los controles afectados. No se exige otro rebuild completo por defecto ni se concede automáticamente PASS a E4. Los nuevos textos sí requieren E0, E2, E6, E7 y la correspondencia E1/E3.

No se permite publicar, lanzar otro build simultáneo, instalar Mathlib, modificar el corte antiguo ni ocultar los informes anteriores.
