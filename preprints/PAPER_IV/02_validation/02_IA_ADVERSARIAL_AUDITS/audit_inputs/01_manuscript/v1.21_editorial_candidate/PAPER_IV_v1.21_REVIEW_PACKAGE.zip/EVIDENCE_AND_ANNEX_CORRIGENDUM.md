# Paper IV v1.21 — aclaraciones de evidencia y anexo

Fecha: 30 de septiembre de 2026. Documento adicional; no sustituye registros históricos.

## Recuento de axiomas (X-20)

El recuento reproducido en `artifact_checks.py`, sobre los 19 logs de `03_reproducibility/full_rebuild_v12_20260929_resume/combined/modules/`, da **314** líneas de salida con `depends on axioms:` y **147** listas de axiomas de elaboradores de auditoría: **461 registros**. Los hashes y subtotales por target están en `AXIOM_COUNT_RECONCILIATION.json`.

La cifra «313 impresiones» del informe interno histórico queda corregida por esta nota. No se deduce de estos totales un número de teoremas distintos. El número 461 del manuscrito era correcto. Esta cuenta tampoco certifica el build externo que está en curso.

## Anexo BoundedCliqueGap (X-25)

En el README histórico del anexo, la remisión a «§8.2» debe leerse como **Apéndice G.1** en las versiones 1.2 y 1.21. El resultado es `BoundedCliqueGap.chordal_gap_linear_cliqueFree`: brecha triangular con número de clique acotado, no brecha mixta universal.

Se preserva el ZIP histórico `05_formalization/LEAN_BOUNDED_GAP_ANNEX_v1.0.zip`, SHA-256 `2847a422865e06880d457ea806aae5b9f749d22359eff325349c09c01cb4837d`. Esta nota debe acompañarlo en la próxima revisión y eventual paquete de publicación. No se ha reemplazado ni recomprimido el ZIP que el auditor está reproduciendo.

## Configuración conservada (X-19)

Algunas entradas `lean_lib` del archivo Lake no tienen módulos en el corte seleccionado. Son configuración residual, no evidencia de una dependencia del teorema. Se mantienen para no alterar el corte compilado; la lista de 607 módulos, sus imports, los tipos y los conos auditados delimitan el alcance real. No se declara que se haya hecho limpieza de esa configuración.

## Límites preservados (X-21, X-22, X-26)

La recuperación del build autoral fue verificada por consistencia de registros; la ausencia de ciertas trazas en el paquete limita su reproducción externa. El auditor está compilando de forma aislada precisamente para producir evidencia propia. La suficiencia de varias pruebas en prosa fue discutida por la auditoría externa pese al PASS interno; ese desacuerdo permanece en los informes originales. Una nueva sesión de la misma familia de modelos no constituye independencia entre familias.
